
-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `idT` int(11) NOT NULL,
  `nomT` varchar(100) DEFAULT NULL,
  `prixT` decimal(10,2) DEFAULT NULL,
  `valeurT` varchar(255) DEFAULT NULL,
  `etatT` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
