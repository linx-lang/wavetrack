
-- --------------------------------------------------------

--
-- Structure for view `v_prixsalle`
--
DROP TABLE IF EXISTS `v_prixsalle`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_prixsalle`  AS  select `a`.`idDev` AS `idDev`,`a`.`idSalle` AS `idSalle`,sum(`a`.`prixAct`) AS `prixAchS`,8205 AS `prixInstallation`,`p`.`prixAbon` AS `prixAbon`,((sum(`a`.`prixAct`) + 8205) + `p`.`prixAbon`) AS `prixTotal`,((sum(`a`.`prixAct`) + 8205) + (`p`.`prixAbon` / 12)) AS `prixMois` from ((`acheter` `a` join `salle` `s` on((`a`.`idSalle` = `s`.`idSalle`))) join `proprietaire` `p` on((`s`.`idPro` = `p`.`idPro`))) group by `a`.`idDev`,`a`.`idSalle` ;
