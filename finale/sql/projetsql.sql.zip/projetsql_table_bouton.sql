
-- --------------------------------------------------------

--
-- Table structure for table `bouton`
--

CREATE TABLE `bouton` (
  `idB` int(11) NOT NULL,
  `etatb` varchar(50) DEFAULT NULL,
  `prix` decimal(10,2) DEFAULT NULL,
  `idSalle` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
