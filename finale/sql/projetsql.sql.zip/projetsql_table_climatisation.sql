
-- --------------------------------------------------------

--
-- Table structure for table `climatisation`
--

CREATE TABLE `climatisation` (
  `idClim` int(11) NOT NULL,
  `etat` varchar(50) DEFAULT NULL,
  `idB` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
