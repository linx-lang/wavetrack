
-- --------------------------------------------------------

--
-- Table structure for table `devis`
--

CREATE TABLE `devis` (
  `idDev` int(11) NOT NULL,
  `prixTot` decimal(10,2) DEFAULT NULL,
  `dateP` datetime DEFAULT NULL,
  `idPro` int(11) DEFAULT NULL,
  `prixClient` decimal(10,0) DEFAULT NULL,
  `prixMois` decimal(11,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
