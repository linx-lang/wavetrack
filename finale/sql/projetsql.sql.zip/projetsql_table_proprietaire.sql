
-- --------------------------------------------------------

--
-- Table structure for table `proprietaire`
--

CREATE TABLE `proprietaire` (
  `idPro` int(11) NOT NULL,
  `nomP` varchar(100) DEFAULT NULL,
  `prenomP` varchar(100) DEFAULT NULL,
  `mailP` varchar(150) DEFAULT NULL,
  `mdpP` varchar(255) DEFAULT NULL,
  `numP` varchar(20) DEFAULT NULL,
  `nomAb` varchar(25) DEFAULT NULL,
  `dateAb` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `nb_salle` int(11) DEFAULT NULL,
  `prixAbon` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
