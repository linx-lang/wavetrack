
-- --------------------------------------------------------

--
-- Table structure for table `porte`
--

CREATE TABLE `porte` (
  `idP` int(11) NOT NULL,
  `idSalle` int(11) DEFAULT NULL,
  `idCap` int(11) DEFAULT NULL,
  `idZone` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
