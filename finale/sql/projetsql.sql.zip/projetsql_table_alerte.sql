
-- --------------------------------------------------------

--
-- Table structure for table `alerte`
--

CREATE TABLE `alerte` (
  `idA` int(11) NOT NULL,
  `date` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `idD` int(11) DEFAULT NULL,
  `idM` int(11) DEFAULT NULL,
  `ValeurA` decimal(11,0) NOT NULL,
  `resolu` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
