
-- --------------------------------------------------------

--
-- Table structure for table `machine`
--

CREATE TABLE `machine` (
  `idM` int(11) NOT NULL,
  `valeurMaxTemp` decimal(10,2) DEFAULT NULL,
  `noM` varchar(100) DEFAULT NULL,
  `valeurMaxWatt` decimal(10,0) NOT NULL,
  `idZone` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
