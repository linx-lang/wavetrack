
-- --------------------------------------------------------

--
-- Table structure for table `salle`
--

CREATE TABLE `salle` (
  `idSalle` int(11) NOT NULL,
  `nomS` varchar(100) DEFAULT NULL,
  `lieus` varchar(255) DEFAULT NULL,
  `capacite` int(11) DEFAULT NULL,
  `codePoS` int(11) NOT NULL,
  `idPro` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
