
-- --------------------------------------------------------

--
-- Table structure for table `acheter`
--

CREATE TABLE `acheter` (
  `prixAct` decimal(10,2) DEFAULT NULL,
  `dateP` datetime DEFAULT NULL,
  `qant` int(11) NOT NULL,
  `idDev` int(11) NOT NULL,
  `idT` int(11) NOT NULL,
  `idSalle` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Triggers `acheter`
--
DELIMITER $$
CREATE TRIGGER `trg_insert_prixAcht` BEFORE INSERT ON `acheter` FOR EACH ROW SET New.prixAct =(
    SELECT t.prixT
    FROM type t
    WHERE t.idT = NEW.idT
) * NEW.qant
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_update_prixtot` AFTER INSERT ON `acheter` FOR EACH ROW UPDATE devis
SET prixTot= (SELECT SUM(prixTotal) FROM v_prixsalle WHERE v_prixsalle.idDev=NEW.idDev)
WHERE `idDev` = NEW.`idDev`
$$
DELIMITER ;
