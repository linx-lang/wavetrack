
-- --------------------------------------------------------

--
-- Table structure for table `ouverture`
--

CREATE TABLE `ouverture` (
  `idJ` int(11) NOT NULL,
  `IdSalle` int(11) NOT NULL,
  `horaireDeb` time DEFAULT NULL,
  `horaireFin` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
