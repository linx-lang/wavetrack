
-- --------------------------------------------------------

--
-- Table structure for table `donnee`
--

CREATE TABLE `donnee` (
  `idD` int(11) NOT NULL,
  `valeur` decimal(10,2) NOT NULL,
  `date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `IdCap` int(11) DEFAULT NULL,
  `Nom` varchar(100) NOT NULL,
  `idB` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Triggers `donnee`
--
DELIMITER $$
CREATE TRIGGER `trg_insert_alerte` AFTER INSERT ON `donnee` FOR EACH ROW BEGIN

    IF EXISTS (
        SELECT 1
        FROM capteurs c
        JOIN machine m ON m.idM = c.idM
        WHERE c.idCap = NEW.idCap
        AND (
            (NEW.Nom = 'Temperature' AND NEW.valeur >= m.valeurMaxTemp)
            OR
            (NEW.Nom = 'Voltage' AND NEW.valeur >= m.valeurMaxWatt)
        )

    ) THEN

        INSERT INTO alerte (ValeurA, idD, idM, date, resolu)

        SELECT
            NEW.valeur,
            NEW.idD,
            c.idM,
            NEW.date, 
            0

        FROM capteurs c
        WHERE c.idCap = NEW.idCap
        LIMIT 1;

    END IF;

END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_insert_alerteM` AFTER INSERT ON `donnee` FOR EACH ROW BEGIN
    IF EXISTS (
        SELECT 1 FROM ouverture h
        JOIN jour j ON j.idJ = h.idJ
        JOIN salle s ON s.idSalle = h.idSalle
        JOIN capteurs c ON c.idSalle = s.idSalle
        JOIN donnee d ON d.idCap = c.idCap
        WHERE d.idD = NEW.idD
        AND NEW.valeur = 1 AND NEW.Nom='Porte'
        AND FIELD(j.nom, 'Dimanche', 'Lundi', 'Mardi', 'Mercredi', 				'Jeudi', 'Vendredi', 'Samedi') = DAYOFWEEK(NEW.date)
        AND TIME(NEW.date) NOT BETWEEN h.horaireDeb AND h.horaireFin
    ) THEN
        INSERT INTO alerte (ValeurA, idD, idM, date)
        SELECT NEW.valeur, NEW.idD, c.idM, NEW.date
        FROM capteurs c
        JOIN donnee d ON d.idCap = c.idCap
        WHERE d.idD = NEW.idD
        LIMIT 1;

    END IF;
END
$$
DELIMITER ;
