document.addEventListener('DOMContentLoaded', () => {
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const tab = btn.dataset.tab;

            tabButtons.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));

            btn.classList.add('active');
            document.getElementById('tab-' + tab).classList.add('active');
        });
    });

    const btnAjouterCreneau = document.getElementById('btn-ajouter-creneau');
    if (btnAjouterCreneau) {
        btnAjouterCreneau.addEventListener('click', () => {
            alert('Ici tu pourras ouvrir un formulaire pour ajouter un créneau.');
        });
    }

    const boutonsResolu = document.querySelectorAll('.btn-resolu');
    boutonsResolu.forEach(btn => {
        btn.addEventListener('click', () => {
            btn.closest('.alerte').style.opacity = '0.5';
        });
    });
});
